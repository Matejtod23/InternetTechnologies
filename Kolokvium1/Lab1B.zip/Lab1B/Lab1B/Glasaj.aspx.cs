﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Lab1B
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void save_Click(object sender, EventArgs e)
        {
            if(lbPredmeti.SelectedItem == null && lbKrediti.SelectedItem == null)
            {
                result.Text = "Селектирајте предмет и кредити";
            }
            else
            {
                Response.Redirect("UspeshnoGlasanje.aspx");
            }
        }

        protected void add_Click(object sender, EventArgs e)
        {
            ListItem predmetItem = new ListItem();
            ListItem kreditItem = new ListItem();
            predmetItem.Text = predmet.Text;
            kreditItem.Text = kredit.Text;
            lbPredmeti.Items.Add(predmetItem);
            lbKrediti.Items.Add(kreditItem);
            
        }

        protected void lbPredmeti_SelectedIndexChanged(object sender, EventArgs e)
        {
            lblProfesor.Text = lbPredmeti.SelectedItem.Value.ToString();
        }

        protected void remove_Click(object sender, EventArgs e)
        {
            ListItemCollection items = lbPredmeti.Items;
            for (int i = 0; i < items.Count; i++)
            {
                if (items[i].Selected == true)
                {
                    lbPredmeti.Items.RemoveAt(i);
                    lbKrediti.Items.RemoveAt(i);
                }
            }
        }
    }
}